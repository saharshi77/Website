SAFFRON TABLE - RESTAURANT WEBSITE

This version includes local image files in the images folder.
The website no longer depends on external Unsplash photo links.

How to run:
1. Extract the ZIP file.
2. Keep index.html and the images folder together.
3. Double-click index.html to open it in Chrome.

Important:
- Do not move index.html away from the images folder.
- The reservation form is a front-end demo only; it does not send bookings to a server.

Technologies: HTML, CSS and JavaScript.
